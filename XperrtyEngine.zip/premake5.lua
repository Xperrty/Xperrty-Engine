workspace "Xperrty"
    architecture "x64"

configurations
{
    "Debug",
    "Release",
    "Dist"
}

outputdir = "%{cfg.buildcfg}-%{cfg.system}-%{cfg.architecture}"

project "XperrtyEngine"
    location "XperrtyEngine"
    kind "SharedLib"
    language "C++"

    targetdir ("bin/" .. outputdir .. "/%{prj.name}")
    objdir ("bin-int/" .. outputdir .. "/%{prj.name}")

    files
    {
        "%{prj.name}/src/**.h",
        "%{prj.name}/src/**.cpp"
    }

    include{
        "%{prj.name}/vendor/spdlog/include"
    }

    filter "system:windows"
        cppdialect "C++17"
        staticruntime "On"
        systemversion "latest"

        defines{
            "XP_PLATFORM_WINDOWS",
            "XP_BUILD_DLL",
            "_CONSOLE",
            -- XP_PLATFORM_WINDOWS;XP_BUILD_DLL;_DEBUG;_CONSOLE;%(PreprocessorDefinitions)
            -- XP_PLATFORM_WINDOWS;XP_BUILD_DLL;NDEBUG;_CONSOLE;%(PreprocessorDefinitions)
        }

        postbuildcommands{
            ("{COPY} %{cfg.buildtarget.relpath} ../bin/" .. outputdir .. "/Sandbox")
        }
    
        filter "configurations:Debug"
            defines "XP_DEBUG"
            symbols "On"

        filter "configurations:Release"
            defines "XP_RELEASE"
            optimize "On"

        filter "configurations:DIST"
            defines "XP_DIST"
            optimize "On"

        filter {"system:windows","configurations:Release"}
            buildoptions: "/MT"

project "Sandbox"
    location "Sandbox"
    kind "ConsoleApp"
    language "C++"

    targetdir ("bin/" .. outputdir .. "/%{prj.name}")
    objdir ("bin-int/" .. outputdir .. "/%{prj.name}")

    files
    {
        "%{prj.name}/src/**.h",
        "%{prj.name}/src/**.cpp"
    }

    include{
        "%{prj.name}/vendor/spdlog/include",
        "XperrtyEngine/src"
    }
    
    links{
        "XperrtyEngine"
    }

    filter "system:windows"
        cppdialect "C++17"
        staticruntime "On"
        systemversion "latest"

        defines{
            "XP_PLATFORM_WINDOWS",
            "_CONSOLE",
            -- XP_PLATFORM_WINDOWS;XP_BUILD_DLL;_DEBUG;_CONSOLE;%(PreprocessorDefinitions)
            -- XP_PLATFORM_WINDOWS;XP_BUILD_DLL;NDEBUG;_CONSOLE;%(PreprocessorDefinitions)
        }

        postbuildcommands{
            ("{COPY} %{cfg.buildtarget.relpath} ../bin/" .. outputdir .. "/Sandbox")
        }
    
        filter "configurations:Debug"
            defines "XP_DEBUG"
            symbols "On"

        filter "configurations:Release"
            defines "XP_RELEASE"
            optimize "On"

        filter "configurations:DIST"
            defines "XP_DIST"
            optimize "On"

        filter {"system:windows","configurations:Release"}
            buildoptions: "/MT"