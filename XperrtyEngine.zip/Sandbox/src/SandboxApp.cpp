
#include "Xperrty.h"

class SandboxApp :public  Xperrty::Application {
public:
	SandboxApp() {
		TRACE("TRACE! {0}",10);
		INFO("INFO!{0}", 11);
		WARN("WARN!{0}", 12);
		ERROR("ERROR{0}", 13);
	}
};


Xperrty::Application* Xperrty::createApplication() {
	return new SandboxApp();
}