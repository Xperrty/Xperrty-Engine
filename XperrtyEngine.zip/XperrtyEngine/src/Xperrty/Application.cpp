
#include "Application.h"
namespace Xperrty {

	Application::Application()
	{

	}

	Application::~Application()
	{


	}
	void Application::run() {
		std::cout << "RUN!" << std::endl;
	}

}
