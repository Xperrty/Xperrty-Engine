#pragma once

#ifdef XP_PLATFORM_WINDOWS
	#ifdef XP_BUILD_DLL
		#define dllie __declspec(dllexport)
	#else
		#define dllie __declspec(dllimport)
	#endif
#else 
#error Only Supports Windows!
#endif // XP_BUILD_DLL