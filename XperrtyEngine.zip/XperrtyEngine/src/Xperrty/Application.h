#pragma once
#include <iostream>
#include "Core.h"
namespace Xperrty {


	class dllie Application
	{
	public:
		Application();
		virtual ~Application();
		void run();
	};

	Application* createApplication();
}
