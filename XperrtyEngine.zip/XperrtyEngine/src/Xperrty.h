#pragma once
#include "Xperrty/Application.h"

#include "Xperrty/Utils/Log.h"

#include "Xperrty/EntryPoint.h"